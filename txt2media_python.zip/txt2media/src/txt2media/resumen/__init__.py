"""Subpaquete convdoc.resumen."""
