"""Subpaquete convdoc.cli."""
